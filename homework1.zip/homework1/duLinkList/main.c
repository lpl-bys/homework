#include "../head/duLinkedList.h"

DuLNode *head,*tail;
int flag;

void inst(void);
void pinf(ElemType e);
void enter_wrong(void);
void backmain(void);
void mainlist(void);
void Initialize(void); 
void addnode(void);
void showall(void);
void Insertafter(void);
void Insertbefore(void);
void Delete(void);
void shownow(void);

int main(){//
	system("color 1F");
	inst();
	mainlist();
	return 0;	
}

void shownow(void){//
	printf("Now the DUlinked line is:\n");
	TraverseList_DuL(head,pinf);
	printf("\n");
}

void inst(void){//
	head=NULL;tail=NULL;flag=0;
}

void pinf(ElemType e){//
	printf("%d",e);
}

void enter_wrong(void){//
	printf("Enter wrong!Please enter any key to back to the mainlist...");
	getchar();			  			
}

void Delete(void){//
	system("cls");
	shownow();
	int wz,i;
	ElemType e;
	DuLNode *t=head;
	printf("Please enter the position of the node you want to delete:");
	scanf("%d",&wz);getchar();
	for(i=2;i<wz;i++) t=t->next;
	DeleteList_DuL(t,&e);
	//printf("dfadsf");
	t=NULL;
	printf("Delete successful!The data you delete is %d\n",e);
	shownow();
	backmain();
}

void Insertafter(void){//
	system("cls");
	shownow();
	int wz,i;
	ElemType e;
	DuLNode *po,*t;
	printf("Please enter the node's position you want to insert after:");
	scanf("%d",&wz);getchar();
	printf("Please enter the date of new node:");
	scanf("%d",&e);getchar();
	t=(DuLNode *)malloc(sizeof(DuLNode));
	if(t==NULL){
		printf("Insert error!Please Contact the maker!\n");
		getchar();
		exit(0);
	}
	t->data=e;po=head;
	for(i=1;i<wz;i++) po=po->next;
	if(InsertAfterList_DuL(po,t)){
		if(tail==po) tail=t;
		printf("Insert successful!\n");
	}
	else printf("Insert error!Please Contact the maker!\n");
	shownow();
	backmain();
}

void Insertbefore(void){
	system("cls");
	shownow();
	int wz,i;
	ElemType e;
	DuLNode *po,*t;
	printf("Please enter the node's position you want to insert before:");
	scanf("%d",&wz);getchar();
	printf("Please enter the date of new node:");
	scanf("%d",&e);getchar();
	t=(DuLNode *)malloc(sizeof(DuLNode));
	if(t==NULL){
		printf("Insert error!Please Contact the maker!\n");
		getchar();
		exit(0);
	}
	t->data=e;po=head;
	for(i=1;i<wz;i++) po=po->next;
	if(InsertBeforeList_DuL(po,t)){
		if(head==po) head=t;
		printf("Insert successful!\n");
	}
	else printf("Insert error!Please Contact the maker!\n");
	shownow();
	backmain();
}

void showall(void){//
	system("cls");
	if(!flag) printf("The DULinked line isn't existing!\n");
	else if(head->data){
		TraverseList_DuL(head,pinf);
		printf("\n\n\nShow successful!\n");
	}
	else printf("The DULinked line is empty!\n");
	backmain();
}

void backmain(void){//
	printf("Please enter any key to back to mainlist...");getchar();
	mainlist();
}

void Initialize(void){//
	system("cls");
	if(flag) printf("The DUlinked line had been Initialized!\n");
	else if(InitList_DuL(&head)){
		flag=1;
		tail=head;
		printf("Initialize successful!\n");
	}
	else{
		printf("Initialize error!Please Contact the maker!\n");	
		getchar();
		exit(0);
	}
	backmain();
}

void addnode(void){//
	system("cls");
	ElemType e;
	char mp;
	DuLNode *t;
	printf("Please enter new node's data:");
	scanf("%d",&e);getchar();
	if(head->data==NULL){
		head->data=e;
		shownow();
		printf("Add successful!Continue?(Y/N):\n");
		scanf("%c",&mp);getchar();
		if(mp=='Y'||mp=='y') addnode();
		else if(mp!='N'&&mp!='n') enter_wrong();
	}
	else{
		t=(DuLNode *)malloc(sizeof(DuLNode));
		t->data=e;
		if(InsertAfterList_DuL(tail,t)){
			tail=t;
			shownow();
			printf("Add successful!Continue?(Y/N):\n");
			scanf("%c",&mp);getchar();
			if(mp=='Y'||mp=='y') addnode();
			else if(mp!='N'&&mp!='n') enter_wrong();
		}
	  	else{
			printf("Add wrong!Please Contact the maker!");
			free(t);t=NULL;
			getchar();
			exit(0);
		}
	}
	backmain();
}

void mainlist(void){
	char temp;
	system("cls");
	printf("************************************** Welcome to use the linked list maker **************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Initialize an empty DU linked list  |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Add nodes                           |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Insert after a node                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Insert before a node                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. Destroy the linked list             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Delete nodes                        |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     7. Show all the linked list            |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     8. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation mode...");
	scanf("%c",&temp);getchar();
	switch(temp){		  
		case '1': Initialize();
		    break;
		case '2': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else addnode();
		    break;
		case '3': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else Insertafter(); 
			break;
		case '4': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else Insertbefore();
			break;
		case '5': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else{
				  	system("cls");
				    DestroyList_DuL(&head);
				    printf("Destroy successful!");
				    inst();
				    backmain();
				  }
			break; 
		case '6': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else Delete();
			break;
		case '7': if(!flag){
					printf("The DULinked line isn't existing!\n");
					backmain();
				  }
				  else showall();
			break;
		case '8': exit(0);
			break;
		default: 
				enter_wrong();
				mainlist();
	}
}



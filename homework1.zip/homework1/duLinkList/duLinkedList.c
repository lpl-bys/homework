#include "../head/duLinkedList.h"

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	(*L)=(DuLNode *)malloc(sizeof(DuLNode));
	if((*L)==NULL) return ERROR;
    (*L)->next=NULL;
    (*L)->prior=NULL; 
	(*L)->data=NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	DuLNode *t=NULL;
	while(*L){
		t=(*L);
		(*L)=(*L)->next;
		free(t);
	}
	t=NULL;
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	if(p==NULL||q==NULL) return ERROR;
	DuLNode *t;
	t=p->prior;
	if(!t){
		q->next=p;
		p->prior=q;
		q->prior=NULL;
	}
	else{
		q->next=p;
		q->prior=t;
		t->next=q;
		p->prior=q;	
	}
	return SUCCESS;
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {
	if(p==NULL||q==NULL) return ERROR;
	DuLNode *t;
	t=p->next;
	if(!t){
		p->next=q;
		q->prior=p;
		q->next=NULL;
	}
	else{
		q->next=t;
		q->prior=p;
		p->next=q;
		t->prior=q;	
	}
	return SUCCESS;
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	if(p==NULL||p->next==NULL) return ERROR;
	DuLNode *t,*tn;
	t=p->next;tn=t->next;
	*e=t->data;
	free(t);t=NULL;
	if(!tn) p->next=NULL;
	else{
		p->next=tn;
		tn->prior=p;
	}
	return SUCCESS;
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
	while(L){
		(*visit)(L->data);
		L=L->next;
		if(L) printf(" <=> ");
	}
}

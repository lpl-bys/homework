#include "../head/linkedList.h"
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L){
	(*L)=(LNode *)malloc(sizeof(LNode));
	if((*L)==NULL) return ERROR;
    (*L)->next=NULL;
	(*L)->data=NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	LNode *t=NULL;
	while(*L){
		t=(*L);
		(*L)=(*L)->next;
		free(t);
	}
	t=NULL;
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {
	if(p==NULL||q==NULL) return ERROR;
	q->next=p->next;
	p->next=q;
	return SUCCESS;
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e) {
	if(p==NULL||p->next==NULL) return ERROR;
	LNode *t=p->next;
	*e=t->data;
	t=t->next;
	free(p->next);
	p->next=t;
	return SUCCESS;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
	while(L){
		(*visit)(L->data);
		L=L->next;
		if(L) printf(" -> ");
	}
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
	while(L){
		if(L->data==e) return SUCCESS;
		L=L->next;
	}
	return ERROR;
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
	if(*L==NULL) return ERROR;
	if((*L)->next==NULL) return SUCCESS; 
	LNode *pre,*cur,*t;
	pre=*L;
	cur=(*L)->next;
	while(cur){
		t=cur->next;
		cur->next=pre;
		pre=cur;
		cur=t;
	}
	(*L)->next=NULL;
	(*L)=pre;
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
	if(L->next==NULL) return ERROR;
	LNode *fa,*sl;
	int i;
	fa=L;sl=L;
	while(1){
		for(i=1;i<=2;i++){
			fa=fa->next;
			if(fa==NULL) return ERROR;
		}
		sl=sl->next;
		if(fa==sl) return SUCCESS;
	}
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L) {
	if(((*L)->next==NULL)||((*L)==NULL)) return (*L);
	LNode *pre,*cur,*te,*nh,*t;
	pre=(*L);cur=(*L)->next;te=NULL;t=NULL;nh=cur;
	while(1){
		pre->next=NULL;
		t=pre;
		pre=cur->next;
		cur->next=t;
		if(te) te->next=cur;
		te=t;
		if(pre&&pre->next) cur=pre->next;
		else break;
	}
	return nh;
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L) {
	LNode *fa,*sl;
	int i;
	fa=(*L);sl=(*L);
	while(fa&&fa->next){
		for(i=1;i<=2;i++) fa=fa->next;
		sl=sl->next;
	}
	return sl;
}


#include "../head/linkedList.h"

LNode *head,*tail;
int flag;

void inst(void);
void pinf(ElemType e);
void enter_wrong(void);
void backmain(void);
void mainlist(void);
void Initialize(void); 
void addnode(void);
void showall(void);
void Insert(void);
void Delete(void);
void Find(void);
void FindMid(void);
void shownow(void);

int main(){
	system("color 1F");
	inst();
	mainlist();
	return 0;	
}

void shownow(void){
	printf("Now the linked line is:\n");
	TraverseList(head,pinf);
	printf("\n");
}

void inst(void){
	head=NULL;tail=NULL;flag=0;
}

void pinf(ElemType e){
	printf("%d",e);
}

void enter_wrong(void){
	printf("Enter wrong!Please enter any key to back to the mainlist...");
	getchar();			  			
}

void FindMid(void){
	system("cls");
	LNode *t;
	t=FindMidNode(&head);
	printf("Find successful!The middle node is %d.\n",t->data);
	backmain();
}

void Find(void){
	system("cls");
	ElemType e;
	printf("Please enter the data of node you want to find:");
	scanf("%d",&e);getchar();
	if(SearchList(head,e)) printf("The node is existing!\n");
	else printf("The node isn't existing.\n");
	backmain();
}

void Delete(void){
	system("cls");
	shownow();
	int wz,i;
	ElemType e;
	LNode *t=head;
	printf("Please enter the position of the node you want to delete:");
	scanf("%d",&wz);getchar();
	for(i=2;i<wz;i++) t=t->next;
	DeleteList(t,&e);
	t=NULL;
	printf("Delete successful!The data you delete is %d\n",e);
	shownow();
	backmain();
}

void Insert(void){
	system("cls");
	shownow();
	int wz,i;
	ElemType e;
	LNode *po,*t;
	printf("Please enter the node's position you want to insert after:");
	scanf("%d",&wz);getchar();
	printf("Please enter the date of new node:");
	scanf("%d",&e);getchar();
	t=(LNode *)malloc(sizeof(LNode));
	if(t==NULL){
		printf("Insert error!Please Contact the maker!\n");
		getchar();
		exit(0);
	}
	t->data=e;po=head;
	for(i=1;i<wz;i++) po=po->next;
	if(InsertList(po,t)){
		if(tail==po) tail=t;
		printf("Insert successful!\n");
	}
	else printf("Insert error!Please Contact the maker!\n");
	shownow();
	backmain();
}

void showall(void){
	system("cls");
	if(!flag) printf("The Linked line isn't existing!\n");
	else if(head->data){
		TraverseList(head,pinf);
		printf("\n\n\nShow successful!\n");
	}
	else printf("The Linked line is empty!\n");
	backmain();
}

void backmain(void){
	printf("Please enter any key to back to mainlist...");getchar();
	mainlist();
}

void Initialize(void){
	system("cls");
	if(flag) printf("The linked line had been Initialized!\n");
	else if(InitList(&head)){
		flag=1;
		tail=head;
		printf("Initialize successful!\n");
	}
	else{
		printf("Initialize error!Please Contact the maker!\n");	
		getchar();
		exit(0);
	}
	backmain();
}

void addnode(void){
	system("cls");
	ElemType e;
	char mp;
	LNode *t;
	printf("Please enter new node's data:");
	scanf("%d",&e);getchar();
	if(head->data==NULL){
		head->data=e;
		shownow();
		printf("Add successful!Continue?(Y/N):\n");
		scanf("%c",&mp);getchar();
		if(mp=='Y'||mp=='y') addnode();
		else if(mp!='N'&&mp!='n') enter_wrong();
	}
	else{
		t=(LNode *)malloc(sizeof(LNode));
		t->data=e;
		if(InsertList(tail,t)){
			tail=t;
			shownow();
			printf("Add successful!Continue?(Y/N):\n");
			scanf("%c",&mp);getchar();
			if(mp=='Y'||mp=='y') addnode();
			else if(mp!='N'&&mp!='n') enter_wrong();
		}
	  	else{
			printf("Add wrong!Please Contact the maker!");
			free(t);t=NULL;
			getchar();
			exit(0);
		}
	}
	backmain();
}

void mainlist(void){
	char temp;
	system("cls");
	printf("************************************** Welcome to use the linked list maker **************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     a. Initialize an empty linked list     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     b. Add nodes                           |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     c. Insert a node                       |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     d. Destroy the linked list             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     e. Delete nodes                        |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     f. Find a node                         |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     g. Show all the linked list            |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     h. Judge hoop                          |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     i. Reverse list                        |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     j. Reverse even number                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     k. Find middle node                    |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     l. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation mode...");
	scanf("%c",&temp);getchar();
	switch(temp){		  
		case 'a': Initialize();
		    break;
		case 'b': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else addnode();
		    break;
		case 'c': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  }
				  else Insert(); 
			break;
		case 'd': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  }
				  else{
						system("cls");
				    	DestroyList(&head);
						printf("Destroy successful!");
						inst();
				    	backmain();
				  }
			break; 
		case 'e': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  }
				  else Delete();
			break;
		case 'f': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else Find();
			break;
		case 'g': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else showall();
			break;
		case 'h': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else{
					  system("cls");
					  if(IsLoopList(head)) printf("The linked line is looped!\n");
					  else printf("The linked line isn't looped.\n");
					  backmain();
		          }
			break;
		case 'i': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else{
			         system("cls");
		        	 shownow();
				 	 if(ReverseList(&head)) printf("Reverse successful!\n");
				  	 else{
				  	    printf("Reverse error!Please contact the maker!\n");
				  	    exit(0);
				 	 }
				     shownow();
				     backmain();
			    	}
			break;
		case 'j': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else {
					   system("cls");
					  shownow();
					  head=ReverseEvenList(&head);
					  printf("Reverse successful!\n");
				  	  shownow();
				 	  backmain();
			 	}
			break;
		case 'k': if(!flag){
					printf("The Linked line isn't existing!\n");
					backmain();
				  } 
				  else FindMid();
			break;
		case 'l': exit(0);
			break;
		default: 
				enter_wrong();
				mainlist();
	}
}



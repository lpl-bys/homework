#include <stdio.h>
#include <string.h>

#define maxn 233

int n;
long long f[maxn];

int main(){
	memset(f,0,sizeof(f));
	scanf("%d",&n);getchar();
	f[0]=1;//��ʼ��ֵ 
	for(int i=0;i<n;i++){
		f[i+1]+=f[i];//��һ�� 
		f[i+2]+=f[i];//������ 
	}
	printf("%lld",f[n]);
	return 0;
}

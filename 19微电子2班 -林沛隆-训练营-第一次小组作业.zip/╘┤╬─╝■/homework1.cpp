#include <stdio.h>
#include <string.h>

#define maxn 2333

char s[maxn],zs[maxn];
int zsn,sn,yy[maxn],centre,ma,mai,a;

int main(){
	memset(s,0,sizeof(s));
	memset(zs,0,sizeof(zs));
	memset(yy,0,sizeof(yy));
	zsn=0;centre=0;ma=0;mai=1;
	scanf("%s",s);getchar();
	sn=strlen(s);
	zs[0]='#';
	for(int i=0;i<sn;i++){//Ԥ���� 
		zs[++zsn]=s[i];
		zs[++zsn]='#';
	}
	
	for(int i=1;i<zsn;i++)//Ѱ��������Ӵ� 
		if((centre+yy[centre]<=i)||((centre+yy[centre])<=(i+yy[centre*2-i]))){
			a=1;
			while(i+a<=zsn&&i-a>=0&&zs[i+a]==zs[i-a]) a++;
			centre=i;
			yy[i]=a-1;
			if(yy[i]>ma){
				mai=i;
				ma=yy[i];
			}
		}
		else yy[i]=yy[centre*2-i];
	
	for(int i=mai-ma;i<=mai+ma;i++)//���������Ӵ� 
		if(zs[i]!='#') printf("%c",zs[i]);
	return 0;
} 

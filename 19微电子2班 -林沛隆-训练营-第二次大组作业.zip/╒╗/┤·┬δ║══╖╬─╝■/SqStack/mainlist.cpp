#include "../head/mainlist.h"

void mainlist(void){
	char temp[2333];
	memset(temp,0,sizeof(temp));
	system("cls");
	printf("****************************************** Welcome to use Stack Maker *************************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Initialize the stack                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Judge empty                         |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Get the top element                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Empty the stack                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. Destroy the stack                   |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Get the length of stack             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     7. Put in new elements                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     8. Put out the elements                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     9. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation...");
	scanf("%s",temp);getchar();
	switch(temp[0]){
		case '1': 
			if(flag){
				printf("The stack had been initialized!\n");
				enter_back();mainlist();
			}
			else Initialize_Stack();
		    break;
		case '2':
			if(!flag) printf("The stack has not been initialized!\n");
			else Judge_Empty();
			enter_back();mainlist();
		    break;
		case '3':
			if(!flag) printf("The stack has not been initialized!\n");
			else Get_TopElem();
			enter_back();mainlist();
		    break;
		case '4':
			if(!flag) printf("The stack has not been initialized!\n");
			else Empty_Stack();
			enter_back();mainlist();
		    break;
		case '5':
			if(!flag) printf("The stack has not been initialized!\n");
			else Destroy_Stack();
			enter_back();mainlist();
		    break;
		case '6':
			if(!flag) printf("The stack has not been initialized!\n");
			else Get_StackLen();
			enter_back();mainlist();
		    break;
		case '7':
			if(!flag){
				printf("The stack has not been initialized!\n");
				enter_back();mainlist();
			}
			else PutIn_Stack();
		    break;
		case '8':
			if(!flag){
				printf("The stack has not been initialized!\n");
				enter_back();mainlist();
			}
			else PutOut_Stack();
		    break;
		case '9': exit(0);
			break;
		default: 
				enter_wrong();
				enter_back();
				mainlist();
	}
}

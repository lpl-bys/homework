#include "../head/operation.h"

void Initialize_Stack(void){
	system("cls");
	int si;
	printf("Please enter the sizes of the stack:");
	scanf("%d",&si);getchar();
	if(si<=0){
		printf("The size has to greater than zero!\nPlease enter any key to try again...");
		getchar();
		Initialize_Stack();
	}
	else{
		sq=(SqStack *)malloc(sizeof(SqStack));
		if(!sq) run_wrong();
		if(initStack(sq,si)){
			printf("Initialize successful!\n");
			flag=1;
			enter_back();mainlist();
		}
		else run_wrong();
	}
}

void Judge_Empty(void){
	system("cls");
	if(isEmptyStack(sq)) printf("The stack is empty!\n");	
	else printf("The stack isn't empty!\n");
}

void Get_TopElem(void){
	system("cls");
	if(isEmptyStack(sq)) printf("The stack is empty!You can't read the top element.\n");
	else{
		ElemType t;
		if(getTopStack(sq,&t)) printf("Get successful!The top element is %d\n",t);
		else run_wrong();
	}
}

void Empty_Stack(void){
	system("cls");
	if(clearStack(sq)) printf("Empty successful!\n");
	else run_wrong();
}

void Destroy_Stack(void){
	system("cls");
	if(destroyStack(sq)){
		printf("Destroy successful!\n");
		flag=0;
	}
	else run_wrong();
}

void Get_StackLen(void){
	system("cls");
	int t;
	if(stackLength(sq,&t)){
		printf("Get successful!The length of the stack is %d\n",t);
	}
	else run_wrong();
}

void PutIn_Stack(void){
	system("cls");
	if(sq->size-1<=sq->top){
		printf("The stack is full!You can't put new element in it.\n");
		enter_back();
		mainlist();
	}
	else{
		char temp[2333];
		memset(temp,0,sizeof(temp));
		ElemType t;
		printf("Please enter new element:");
		scanf("%d",&t);getchar();	
		if(pushStack(sq,t)){
			printf("Put in successful!\nContinue to put in?(Y/N):");
			scanf("%s",temp);getchar();
			if(temp[0]=='Y'||temp[0]=='y') PutIn_Stack();
			else if(temp[0]=='N'||temp[0]=='n') mainlist();
			else{
				enter_wrong();
				enter_back();
				mainlist();
			}
		}
		else run_wrong();
	}
}

void PutOut_Stack(void){
	system("cls");
	if(isEmptyStack(sq)){
		printf("The stack is empty!You can't put element out from it.\n");
		enter_back();
		mainlist();
	}
	else{
		char temp[2333];
		memset(temp,0,sizeof(temp));
		ElemType t;
		if(popStack(sq,&t)){
			printf("Put out successful!The element is %d.\nContinue to put out?(Y/N):",t);
			scanf("%s",temp);getchar();
			if(temp[0]=='Y'||temp[0]=='y') PutOut_Stack();
			else if(temp[0]=='N'||temp[0]=='n') mainlist();
			else{
				enter_wrong();
				enter_back();
				mainlist();
			}
		}
		else run_wrong();
	}
}

#include "../head/mainlist.h"

SqStack *sq;
int flag;

int main(){
	system("color 1F");
	sq=NULL;
	flag=0;
	mainlist();
	return 0;
}

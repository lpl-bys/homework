#include "../head/SqStack.h"

Status initStack(SqStack *s,int sizes){//��ʼ��ջ
	if(!s) return ERROR;
	s->elem=(ElemType *)malloc(sizeof(ElemType)*sizes);
	if(!s->elem) return ERROR;
	s->top=-1;s->size=sizes;
	return SUCCESS;
}

Status isEmptyStack(SqStack *s){//�ж�ջ�Ƿ�Ϊ��
	if(s->top<0) return SUCCESS;
	else return ERROR;
}

Status getTopStack(SqStack *s,ElemType *e){//�õ�ջ��Ԫ��
	if(!s) return ERROR;
	ElemType *t=s->elem+s->top;
	*e=(*t);
	return SUCCESS;
} 

Status clearStack(SqStack *s){//���ջ
	if(!s) return ERROR;
	s->top=-1;
	return SUCCESS;
}

Status destroyStack(SqStack *s){//����ջ
	if(!s) return ERROR;
	free(s);s=NULL;
	return SUCCESS;
}

Status stackLength(SqStack *s,int *length){//���ջ����
	if(!s) return ERROR;
	*length=s->top+1;
	return SUCCESS;
}

Status pushStack(SqStack *s,ElemType data){//��ջ
	if(!s) return ERROR;
	s->top++;
	ElemType *t=s->elem+s->top;
	*t=data; 
	return SUCCESS;
}

Status popStack(SqStack *s,ElemType *data){//��ջ
	if(!s) return ERROR;
	ElemType *t=s->elem+s->top;
	*data=(*t);
	s->top--;
	return SUCCESS;
}

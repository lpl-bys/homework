#include "../head/LinkStack.h"

Status initLStack(LinkStack *s){//��ʼ��ջ
	if(!s) return ERROR;
	s->count=NULL;s->top=NULL;
	return SUCCESS;
}

Status isEmptyLStack(LinkStack *s){//�ж�ջ�Ƿ�Ϊ��
	if(!s->count) return SUCCESS;
	else return ERROR;
} 

Status getTopLStack(LinkStack *s,ElemType *e){//�õ�ջ��Ԫ��
	if(!s) return ERROR;
	*e=s->top->data;
	return SUCCESS;
}

Status clearLStack(LinkStack *s){//���ջ
	if(!s) return ERROR;
	LinkStackPtr t;
	while(s->top){
		t=s->top;
		s->top=s->top->next;
		free(t);t=NULL;
		s->count--;
	}
	return SUCCESS;
}

Status destroyLStack(LinkStack *s){//����ջ
	if(!s||!clearLStack(s)) return ERROR;
	free(s);
	return SUCCESS;
}

Status LStackLength(LinkStack *s,int *length){//���ջ����
	if(!s) return ERROR;
	*length=s->count;
	return SUCCESS;
}

Status pushLStack(LinkStack *s,ElemType data){//��ջ
	LinkStackPtr t;
	t=(LinkStackPtr)malloc(sizeof(StackNode));
	if(!s||!t) return ERROR;
	t->data=data;
	t->next=s->top;
	s->top=t;
	s->count++;
	return SUCCESS;
}

Status popLStack(LinkStack *s,ElemType *data){//��ջ
	if(!s) return ERROR;
	LinkStackPtr t=s->top;
	s->top=t->next;
	*data=t->data;
	free(t);t=NULL;
	s->count--;
	return SUCCESS;
}

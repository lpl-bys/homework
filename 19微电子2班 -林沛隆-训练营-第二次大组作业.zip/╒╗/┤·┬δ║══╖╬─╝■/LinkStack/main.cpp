#include "../head/Linkmainlist.h"

LinkStack *sq;
int flag;

int main(){
	system("color 1F");
	flag=0;
	sq=NULL;
	Linkmainlist();
	return 0;
}

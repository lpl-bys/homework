#include "../head/Linkoperation.h"

void LinkInitialize(void){
	system("cls");
	sq=(LinkStack *)malloc(sizeof(StackNode));
	if(initLStack(sq)){
		printf("Initialize successful!\n");
		flag=1;
		enter_back();
		Linkmainlist();
	}
	else run_wrong();
}

void LinkJudge(void){
	system("cls");
	printf("Judge successful!\n");
	if(isEmptyLStack(sq)) printf("The Link Stack is empty!\n");
	else printf("The Link Stack isn't empty!\n");
	enter_back();
	Linkmainlist();
}

void LinkGet_Top(void){
	system("cls");
	ElemType t;
	if(isEmptyLStack(sq)) printf("The Link Stack is empty!You can't get the top element.\n"); 
	else{
		if(!getTopLStack(sq,&t)) run_wrong();
		printf("Get successful!\n");
		printf("The top element is %d\n",t);
	}
	enter_back();
	Linkmainlist();
}

void LinkEmpty(void){
	system("cls");
	if(clearLStack(sq)) printf("Empty successful!\n");
	else run_wrong();
	enter_back();
	Linkmainlist();
}

void LinkDestroy(void){
	system("cls");
	if(destroyLStack(sq)){
		flag=0;
		printf("Destroy successful!\n");
	}
	else run_wrong();
	enter_back();
	Linkmainlist();
}

void LinkGetlen(void){
	system("cls");
	int t;
	if(LStackLength(sq,&t)) printf("Get successful!\nThe length is %d\n",t);
	else run_wrong();
	enter_back();
	Linkmainlist();
}

void LinkPutin(void){
	system("cls");
	ElemType t;
	char temp[2333];
	memset(temp,0,sizeof(temp));
	printf("Please enter new element:");
	scanf("%d",&t);getchar();
	if(pushLStack(sq,t)){
		printf("Put in successful!\nContinue to put in?(Y/N):");
		scanf("%s",temp);getchar();
		if(temp[0]=='Y'||temp[0]=='y') LinkPutin();
		else if(temp[0]=='n'||temp[0]=='N') Linkmainlist();
		else{
			enter_wrong();
			enter_back();
			Linkmainlist();
		}
	}
	else run_wrong();
}

void LinkPutout(void){
	system("cls");
	if(isEmptyLStack(sq)){
		printf("The Link Stack is empty!You can't put out the element.\n");	
		enter_back();
		Linkmainlist();
	}
	else{
		ElemType t;
		char temp[2333];
		memset(temp,0,sizeof(temp));
		if(popLStack(sq,&t)){
			printf("Put out successful!\nThe element is %d\n",t);	
			printf("Continue to put out?(Y/N):");
			scanf("%s",temp);getchar();
			if(temp[0]=='Y'||temp[0]=='y') LinkPutout();
			else if(temp[0]=='n'||temp[0]=='N') Linkmainlist();
			else{
				enter_wrong();
				enter_back();
				Linkmainlist();
			}
		}
		else run_wrong();
	}
	
}

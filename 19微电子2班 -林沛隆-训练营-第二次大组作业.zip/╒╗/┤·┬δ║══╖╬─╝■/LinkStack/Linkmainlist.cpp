#include "../head/Linkmainlist.h"

void Linkmainlist(void){
	char temp[2333];
	memset(temp,0,sizeof(temp));
	system("cls");
	printf("****************************************** Welcome to use LinkStack Maker *********************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Initialize the stack                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Judge empty                         |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Get the top element                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Empty the stack                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. Destroy the stack                   |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Get the length of stack             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     7. Put in new elements                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     8. Put out the elements                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     9. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation...");
	scanf("%s",temp);getchar();
	switch(temp[0]){
		case '1': 
			if(flag){
				system("cls");
				printf("The stack had been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkInitialize();
		    break;
		case '2':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkJudge();
		    break;
		case '3':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkGet_Top();
		    break;
		case '4':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkEmpty();
		    break;
		case '5':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkDestroy();
		    break;
		case '6':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkGetlen();
		    break;
		case '7':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkPutin();
		    break;
		case '8':
			if(!flag){
				system("cls");
				printf("The stack has not been initialized!\n");
				enter_back();Linkmainlist();
			}
			else LinkPutout();
		    break;
		case '9': exit(0);
			break;
		default: 
				enter_wrong();
				enter_back();
				Linkmainlist();
	}
}

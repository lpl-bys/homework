#ifndef Linkoperation_H
#define Linkoperation_H

#include "../head/LinkStack.h"
#include "../head/Linkmainlist.h"
#include "../head/public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

extern LinkStack *sq;
extern int flag;

void LinkInitialize(void);
void LinkJudge(void);
void LinkGet_Top(void);
void LinkEmpty(void);
void LinkDestroy(void);
void LinkGetlen(void);	
void LinkPutin(void);
void LinkPutout(void);	
	
#endif

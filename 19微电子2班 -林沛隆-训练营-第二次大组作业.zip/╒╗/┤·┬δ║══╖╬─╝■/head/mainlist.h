#ifndef mainlist_H
#define mainlist_H

#include "../head/operation.h"
#include "../head/public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

extern int flag;


void mainlist(void);

#endif


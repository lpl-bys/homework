#ifndef Linkmainlist_H
#define Linkmainlist_H

#include "../head/Linkoperation.h"
#include "../head/public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

extern int flag;


void Linkmainlist(void);

#endif


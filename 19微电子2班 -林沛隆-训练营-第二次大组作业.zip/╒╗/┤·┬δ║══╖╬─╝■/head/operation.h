#ifndef operation_H
#define operation_H

#include "../head/SqStack.h"
#include "../head/mainlist.h"
#include "../head/public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

extern SqStack *sq;
extern int flag;

void Initialize_Stack(void);
void Judge_Empty(void);
void Get_TopElem(void);
void Empty_Stack(void);
void Destroy_Stack(void);
void Get_StackLen(void);	
void PutIn_Stack(void);
void PutOut_Stack(void);	
	
	

#endif


#ifndef public_H
#define public_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>


void enter_wrong(void);
void run_wrong(void);
void enter_back(void);

#endif


/***************************************************************************************
 *	File Name				:	linkedList.h
 *	CopyRight				:	2020 QG Studio
 *	SYSTEM					:   win10
 *	Create Data				:	2020.3.28
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

 /**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#ifndef LINKEDLIST_H_INCLUDED
#define LINKEDLIST_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
/**************************************************************
*	Macro Define Section
**************************************************************/
#define OVERFLOW -1

/**************************************************************
*	Struct Define Section
**************************************************************/

// define element type
typedef struct ElemType{
	int type; //0---char;1---double
	char cdata;
	double ndata;
}ElemType;

// define struct of linked list
typedef struct LNode {
	ElemType data;
  	struct LNode *next;
} LNode, *LinkedList;

// define Status
typedef enum Status {
	ERROR,
	SUCCESS
} Status;

typedef  struct  LinkStack
{
	LinkedList top;
	int	count;
}LinkStack;
/**************************************************************
*	Prototype Declare Section
**************************************************************/

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L);

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L);

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LinkedList *tail,ElemType *e);

/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the head node
 *	@param		 : p(head), e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LinkedList *p, ElemType *e);

Status popLStack(LinkStack *s,ElemType *data);
Status pushLStack(LinkStack *s,ElemType *data);
Status initLStack(LinkStack *s);
Status destroyLStack(LinkStack *s);
Status clearLStack(LinkStack *s);
 /**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/
#endif

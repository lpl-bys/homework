#ifndef operation_H
#define operation_H

#include "../head/linkedList.h"
#include "../head/public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>


extern LNode *listhead,*listtail,*queuehead,*queuetail;
extern LinkStack *sq;


double operation(void);

#endif


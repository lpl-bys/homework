#ifndef Input_H
#define Input_H

#include "../head/public.h"
#include "../head/linkedList.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

extern LNode *listhead,*listtail;


Status Input_Cheak(char *c,int cn);
double Char_To_Double(char *ct,int ctn);




#endif


#ifndef queue_H
#define queue_H 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

typedef struct ElemType{
	int type;
	char cdata;
	float ndata;
}ElemType;



#endif


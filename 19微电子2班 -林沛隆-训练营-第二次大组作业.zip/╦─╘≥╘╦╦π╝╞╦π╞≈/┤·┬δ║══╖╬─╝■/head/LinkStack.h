#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

typedef struct ElemType{
	int type; //0---char;1---double
	char cdata;
	double ndata;
}ElemType;

// define struct of linked list
typedef struct LNode {
	ElemType data;
  	struct LNode *next;
} LNode, *LinkedList;

// define Status
typedef enum Status {
	ERROR,
	SUCCESS
} Status;

typedef  struct  LinkStack
{
	LinkedList top;
	int	count;
}LinkStack;


Status popLStack(LinkStack *s,ElemType *data);
Status pushLStack(LinkStack *s,ElemType *data);
Status initLStack(LinkStack *s);


#endif 

#include "../head/Input.h"

Status Input_Cheak(char *c,int cn){
	char nber[233];
	ElemType e;
	int lk,rk,nbern,dflag;
	lk=0;rk=0;nbern=0;dflag=0;
	memset(nber,0,sizeof(nber));
	InitList(&listhead);listtail=listhead;
	
	for(int i=0;i<cn;i++)
		if('0'<=c[i]&&c[i]<='9') nber[nbern++]=c[i];
		else if(c[i]=='.')
			if(!nbern||dflag) return ERROR;
			else{
				dflag=1;
				nber[nbern++]=c[i];
			}
		else if(c[i]=='+'||c[i]=='-'||c[i]=='*'||c[i]=='/'){
			if(i==0||i==cn-1||
			   c[i-1]=='('||c[i-1]=='+'||c[i-1]=='-'||c[i-1]=='*'||c[i-1]=='/'||
			   c[i+1]==')'||c[i+1]=='+'||c[i+1]=='-'||c[i+1]=='*'||c[i+1]=='/') return ERROR;
			else{
				if(nbern){
					if(nber[nbern-1]=='.') return ERROR;
					e.type=1;e.ndata=Char_To_Double(nber,nbern);
					InsertList(&listtail,&e);
					memset(nber,0,sizeof(nber));nbern=0;dflag=0;
				}
				e.type=0;e.cdata=c[i];
				InsertList(&listtail,&e);
			}
		}
		else if(c[i]=='('){
			if(nbern) return ERROR;
			else{
				e.type=0;e.cdata=c[i];
				InsertList(&listtail,&e);
				lk++;	
			}
		}
		else if(c[i]==')'){
			if(i<cn-1&&c[i+1]>='0'&&c[i+1]<='9') return ERROR;
			else{
				if(nbern){
					if(nber[nbern-1]=='.') return ERROR;
					e.type=1;e.ndata=Char_To_Double(nber,nbern);
					InsertList(&listtail,&e);
					memset(nber,0,sizeof(nber));nbern=0;dflag=0;
				}
				e.type=0;e.cdata=c[i];
				InsertList(&listtail,&e);
				rk++;
				if(rk>lk) return ERROR;
			}
		}
		else if(c[i]==' ') continue;
		else return ERROR;
	if(nbern){
		if(nber[nbern-1]=='.') return ERROR;
		e.type=1;e.ndata=Char_To_Double(nber,nbern);
		InsertList(&listtail,&e);
		memset(nber,0,sizeof(nber));nbern=0;dflag=0;
	}
	if(rk!=lk) return ERROR;
	return SUCCESS;
}

double Char_To_Double(char *ct,int ctn){
	int xsd=-1;
	double zsnum=0,xsnum=0,num=0;
	for(int i=0;i<ctn;i++)
	   if(ct[i]=='.'){
			xsd=i;
			break;
	   }
	if(xsd<0){
		for(int i=0;i<ctn;i++){
			zsnum*=10.0;
			zsnum+=(double)(ct[i]-'0');
		}
		num=zsnum;
	}
	else{
		for(int i=0;i<xsd;i++){
			zsnum*=10.0;
			zsnum+=(double)(ct[i]-'0');
		}
		for(int i=ctn-1;i>xsd;i--){
			xsnum+=(double)(ct[i]-'0');
			xsnum*=0.1;
		}
		num=zsnum+xsnum;
	}
	return num;
}

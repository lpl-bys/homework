#include "../head/operation.h"

double operation(void){
	ElemType t,temp,a,b;
	//int flag=0;
	InitList(&queuehead);
	queuetail=queuehead;
	sq=(LinkStack *)malloc(sizeof(LinkStack));
	initLStack(sq);
	while(listhead){
		
		t=listhead->data;
		if(t.type) InsertList(&queuetail,&t);
		else{
			if(t.cdata=='(') pushLStack(sq,&t);
			else if(t.cdata==')'){
				while(sq->top->data.cdata!='('){
					popLStack(sq,&temp);
					InsertList(&queuetail,&temp);
				}
				popLStack(sq,&temp);
			}
			else{
				if(!sq->count) pushLStack(sq,&t);
				else{
					if(!sq->top->data.type&&sq->top->data.cdata=='(') pushLStack(sq,&t);
					else if(t.cdata=='+'||t.cdata=='-'){
						while(sq->count&&!sq->top->data.type&&sq->top->data.cdata!='('){
							popLStack(sq,&temp);
							InsertList(&queuetail,&temp);	
						}
						pushLStack(sq,&t);
					}
					else{
					
						while(sq->count&&!sq->top->data.type&&(sq->top->data.cdata=='*'||sq->top->data.cdata=='/')){
							popLStack(sq,&temp);
							InsertList(&queuetail,&temp);
						}
						pushLStack(sq,&t);
					}
				}
				
			}
				
		} 
		
		DeleteList(&listhead,&t);
		//printf("dsfadssdfsdf");
	}
	//printf("1dsfadssdfsdf");
	while(sq->count){
		popLStack(sq,&temp);
		InsertList(&queuetail,&temp);
	}
	while(queuehead){
		t=queuehead->data;
		if(t.type) pushLStack(sq,&t);
		else {
			popLStack(sq,&a);
			popLStack(sq,&b);
			if(t.cdata=='+'){
				temp.type=1;
				temp.ndata=a.ndata+b.ndata;
				pushLStack(sq,&temp);
			}
			else if(t.cdata=='-'){
				temp.type=1;
				temp.ndata=b.ndata-a.ndata;
				pushLStack(sq,&temp);
			}
			else if(t.cdata=='*'){
				temp.type=1;
				temp.ndata=a.ndata*b.ndata;
				pushLStack(sq,&temp);
			}
			else{
				temp.type=1;
				if(!a.ndata){
					printf("Calculation error!Zero can't be a divisor.\n");
					enter_back();exit(0);
				//	break;
				}
				temp.ndata=b.ndata/a.ndata;
				pushLStack(sq,&temp);
			}
		}
		DeleteList(&queuehead,&t);
	}
	popLStack(sq,&temp);
	return temp.ndata;
}

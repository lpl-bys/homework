#include "../head/linkedList.h"

Status initLStack(LinkStack *s){//��ʼ��ջ
	if(!s) return ERROR;
	s->count=NULL;s->top=NULL;
	return SUCCESS;
}

Status pushLStack(LinkStack *s,ElemType *data){//��ջ
	LinkedList t;
	t=(LinkedList)malloc(sizeof(LNode));
	if(!s||!t) return ERROR;
	t->data=(*data);
	/*t->data.type=data->type;
	if(data->type) t->data.ndata=data->ndata;
	else t->data.cdata=data->cdata;*/
	t->next=s->top;
	s->top=t;
	s->count++;
	return SUCCESS;
}

Status popLStack(LinkStack *s,ElemType *data){//��ջ
	if(!s) return ERROR;
	LinkedList t=s->top;
	s->top=t->next;
	*data=t->data;
/*	data->type=t->data.type;
	if(t->data.type) data->ndata=t->data.ndata;
	else data->cdata=t->data.cdata;*/
	free(t);t=NULL;
	s->count--;
	return SUCCESS;
}

Status destroyLStack(LinkStack *s){//����ջ
	if(!s||!clearLStack(s)) return ERROR;
	free(s);
	return SUCCESS;
}

Status clearLStack(LinkStack *s){//���ջ
	if(!s) return ERROR;
	LinkedList t;
	while(s->top){
		t=s->top;
		s->top=s->top->next;
		free(t);t=NULL;
		s->count--;
	}
	return SUCCESS;
}

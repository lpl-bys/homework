#include "../head/linkedList.h"
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L){
	(*L)=(LNode *)malloc(sizeof(LNode));
	if((*L)==NULL) return ERROR;
    (*L)->next=NULL;
    (*L)->data.type=-1;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	LNode *t;
	while(*L){
		t=(*L);
		(*L)=(*L)->next;
		free(t);
	}
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert new node after tail node
 *	@param		 : tail, e
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LinkedList *tail,ElemType *e) {
	if(tail==NULL||e==NULL) return ERROR;
	if((*tail)->data.type<0) (*tail)->data=(*e);
	else{
		LNode *t=(LNode *)malloc(sizeof(LNode));
		/*t->data->type=e->type;
		if(e->type) t->data->ndata=e->ndata;
		else t->data->cdata=e->cdata;*/
		t->data=(*e);
		(*tail)->next=t;
		t->next=NULL;
		*tail=t;
	}
	return SUCCESS;
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the head node
 *	@param		 : p(head), e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LinkedList *p, ElemType *e) {
	if(p==NULL) return ERROR;
	LNode *t=(*p);
	
	*p=t->next;
	*e=t->data;
	free(t);
	return SUCCESS;
}

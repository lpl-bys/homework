#include "../head/public.h"
#include "../head/operation.h"
#include "../head/Input.h"

char c[23333];
int cn;
LNode *listhead,*listtail,*queuehead,*queuetail;
LinkStack *sq;

void list(void);

int main(){
	system("color 1F");
	memset(c,0,sizeof(c));
	cn=0;listhead=NULL;listtail=NULL;queuehead=NULL;queuetail=NULL;
	list();
	return 0;
}

void list(void){
	system("cls");
	printf("**************************************** Welcome to use Arithmetic Device *********************************************\n");
	printf("\n\n\nPlease enter the posture[ Example:  6+(4-2)*3+9/3 [ʽ���м䲻���пո�֧��С�����㣬�ݲ�֧�ָ�������!] ] :\n\n\n\t\t\t");
	scanf("%s",c);getchar();
	cn=strlen(c);
	if(!Input_Cheak(c,cn)){
		enter_wrong();	
		enter_back();
		list();
	}
	else{
		printf("The result is %llf\n",operation());
		DestroyList(&listhead);
		DestroyList(&queuehead);
		destroyLStack(sq);
		memset(c,0,sizeof(c));
		cn=0;listhead=NULL;listtail=NULL;queuehead=NULL;queuetail=NULL;
		enter_back();
		list();
	}
	
}

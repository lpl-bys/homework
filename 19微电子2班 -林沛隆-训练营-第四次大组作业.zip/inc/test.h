#ifndef _test_H
#define _test_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <time.h>

void Make_Testdata(int amount,int maxx);
void Input_Data(int *a,int amount);
void Input_Way(int *a,int *size); 
void Cheak(int *a,int size);







#endif

#include "../inc/operation.h"

int ksmall;
int a[maxn],n,maxx;
extern int nextask;
extern bool mflag;

void Insert_Sort(void){
	system("cls");
	memset(a,0,sizeof(a));
	
	Input_Way(a,&n);
		
	clock_t start=clock();
	insertSort(a,n);
	clock_t diff=clock()-start;
	
	printf("Result:\n");
	Cheak(a,n);
	if(mflag) printf("The runing time is %dms.\n",diff);
	else{
		for(int i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");	
	}
		
	enter_back();
	nextask=0;
}

void Merge_Sort(void){
	system("cls");
	
	int temp[maxn];
	memset(a,0,sizeof(a));
	
	Input_Way(a,&n);

    clock_t start=clock();
	MergeSort(a,0,n-1,temp);
	clock_t diff=clock()-start;
	
	printf("Result:\n");
	Cheak(a,n);
	if(mflag) printf("The runing time is %dms.\n",diff);
	else{
		for(int i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");	
	}		
	
	
	enter_back();
	nextask=0;
}

void Quick_Sort_Recursion(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	
	Input_Way(a,&n);
		
	clock_t start=clock();
	QuickSort_Recursion(a,0,n-1);
	clock_t diff=clock()-start;
	
	printf("Result:\n");
	Cheak(a,n);
	if(mflag) printf("The runing time is %dms.\n",diff);
	else{
		for(int i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");	
	}		
	
	
	enter_back();
	nextask=0;
}

void Count_Sort(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	maxx=0;
	
	printf("Please enter the count:");
	scanf("%d",&n);getchar();
	printf("Please enter the data:");
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(maxx<a[i]) maxx=a[i];
		getchar();
	}
		
	
	CountSort(a,n,maxx);
	
	printf("Result:\n");
	Cheak(a,n);
	for(int i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");		
	
	
	enter_back();
	nextask=0;
}

void RadixCount_Sort(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	
	Input_Way(a,&n);	
	
	clock_t start=clock();
	RadixCountSort(a,n);
	clock_t diff=clock()-start;
	
	printf("Result:\n");
	Cheak(a,n);
	if(mflag) printf("The runing time is %dms.\n",diff);
	else{
		for(int i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");	
	}			
	
	
	enter_back();
	nextask=0;
}

void Color_Sort(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	
	printf("Please enter the count:");
	scanf("%d",&n);getchar();
	printf("Please enter the data(0,1,2):");
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		getchar();
	}
		
	
	ColorSort(a,n);
	
	printf("Result:\n");
	for(int i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");		
	
	
	enter_back();
	nextask=0;
}

void Quick_Sort_NoRecursion(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	
	Input_Way(a,&n);
		
	clock_t start=clock();
	QuickSort(a,n);
	clock_t diff=clock()-start;
	
	printf("Result:\n");
	Cheak(a,n);
	if(mflag) printf("The runing time is %dms.\n",diff);
	else{
		for(int i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");	
	}			
	
	enter_back();
	nextask=0;
}

void Find_K(void){
	system("cls");
	
	memset(a,0,sizeof(a));
	
	printf("Please enter the count:");
	scanf("%d",&n);getchar();
	printf("Please enter the data:");
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		getchar();
	}
	printf("Please enter the small rand of the data which you want to find:");
	scanf("%d",&ksmall);getchar();
	
	FindK(a,n);
	
	printf("Result:\n");
	printf("%d\n",ksmall);
	
	
	enter_back();
	nextask=0;
	
}

#ifndef _operation_H
#define _operation_H

#include "../inc/public.h"
#include "../inc/test.h"
#include "../inc/qgsort.h"
#include <stdio.h>
#include <string.h>
#include <io.h>
#include <time.h>

#define maxn 233333

void Insert_Sort(void);
void Merge_Sort(void);
void Quick_Sort_Recursion(void);
void Count_Sort(void);
void RadixCount_Sort(void);
void Color_Sort(void);
void Quick_Sort_NoRecursion(void);
void Find_K(void);


#endif

#include "../inc/test.h"

bool mflag;

void Make_Testdata(int amount,int maxx){
	printf("Making data...");
	int sj;
	FILE*fp;
	fp=fopen("Test_Data.txt","w+");
	srand((unsigned int)time(0));
	for(int i=1;i<=amount;i++){
		sj=rand() % maxx;
		fprintf(fp,"%d ",sj);
	}
	fclose(fp);
	printf("Success\n");
}

void Input_Data(int *a,int amount){
	printf("Inputting data...");
	FILE*fp;
	fp=fopen("Test_Data.txt","r");
	for(int i=0;i<amount;i++)
		fscanf(fp,"%d",&a[i]);
	fclose(fp);
	printf("Success\n");
}

void Input_Way(int *a,int *size){
	char tem[233];
	int te;
	memset(tem,0,sizeof(tem));
	printf("1.����;2.������  :");
	scanf("%s",tem);getchar();
	if(tem[0]=='1'){
		mflag=0;
		printf("Please enter the count:");
		scanf("%d",size);getchar();
		printf("Please enter the data:");
		for(int i=0;i<(*size);i++){
			scanf("%d",&a[i]);
			getchar();
		}
	}
	else{
		mflag=1;
		printf("Please enter the count:");
		scanf("%d",size);getchar();
		printf("Please enter the max data:");
		scanf("%d",&te);getchar();
		Make_Testdata((*size),te);
		Input_Data(a,(*size));
	}
	printf("Waiting...\n");
}

void Cheak(int *a,int size){
	printf("Cheaking...");
	for(int i=1;i<size;i++)
		if(a[i-1]>a[i]){
			printf("Wrong\n");
			return;
		}
	printf("Right\n");
}

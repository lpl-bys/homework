#include "../inc/operation.h"
#include "../inc/public.h"

int nextask;

void findtask(void);
void mainlist(void);//0

int main(){
	system("color 1F");
	nextask=0;
	while(1) findtask();
	return 0;
}

void findtask(void){
	switch(nextask){
		case 0: mainlist();
			break;
		case 1: Insert_Sort();
			break;
		case 2: Merge_Sort();
			break;
		case 3: Quick_Sort_Recursion();
			break;
		case 4: Count_Sort();
			break;
		case 5: RadixCount_Sort();
			break;
		case 6: Color_Sort();
			break;
		case 7: Quick_Sort_NoRecursion();
			break;
		case 8: Find_K();
			break;
	}
}

void mainlist(void){//0
	system("cls");
	
	char temp[233];
	memset(temp,0,sizeof(temp));
	
	printf("****************************************** Welcome to use que Maker *************************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Insert Sort                         |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Merge Sort                          |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Quick Sort(Recursion)               |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Count Sort                          |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. RadixCount Sort                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Color Sort                          |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     7. Quick Sort(NoRecursion)             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     8. Find small rand                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     a. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation...");
	scanf("%s",temp);getchar();
	switch(temp[0]){
		case '1': nextask=1;
		    break;
		case '2': nextask=2;
		    break;
		case '3': nextask=3;
		    break;
		case '4': nextask=4;
		    break;
		case '5': nextask=5;
		    break;
		case '6': nextask=6;
		    break;
		case '7': nextask=7;
		    break;
		case '8': nextask=8;
		    break;
		case 'a': exit(0);
			break;
		default: 
				enter_wrong();
				enter_back();
				nextask=0;
	}
}

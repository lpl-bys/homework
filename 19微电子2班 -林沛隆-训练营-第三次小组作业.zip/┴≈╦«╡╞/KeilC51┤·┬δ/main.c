#include <reg51.h>

#define uchar unsigned char
#define uint unsigned int

void delayms(uint);


void main(){
	uchar i,a;
 	P0=0xFF;
 	while(1){
		a=0x7F;
	 	for(i=0;i<8;i++){
		   	P0=a;
			delayms(300);
			a=a>>1;
			a=a|0x80;
		}
	}
}

void delayms(uint xms){
 	uint i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
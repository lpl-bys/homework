#include <reg51.h>

#define uchar unsigned char
#define uint unsigned int

uchar code table[]={
  0xC0,0xF9,0xA4,0xB0,	 //0-3
  0x99,0x92,0x82,0xF8,   //4-7
  0x80,0x90				 //8-9
};

void delayms(uint);


void main(){
	 uchar i;
	 P2=1;
	 while(1){
	  	for(i=0;i<10;i++){
		 	P2=table[i];
			delayms(1000);
			P2=1;
		}
	 }
}

void delayms(uint xms){
 	uint i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
#include <reg51.h>

#define uchar unsigned char
#define uint unsigned int

sbit buz=P0^5;

void delayms(uint);

void main(){
	buz=1;
	while(1){
	 	buz=!buz;
		delayms(500);
	}
}

void delayms(uint xms){
 	uint i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
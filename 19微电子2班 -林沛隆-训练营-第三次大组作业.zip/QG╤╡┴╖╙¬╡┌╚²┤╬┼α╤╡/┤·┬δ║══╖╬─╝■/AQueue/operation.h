#ifndef _OPERATION_H
#define _OPERATION_H

#include "AQueue.h"
#include "public.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>



void mainlist(void);
void Initialize_Queue(void);
void Judge_Empty(void);
void Get_TopElem(void);
void Empty_Queue(void);
void Destroy_Queue(void);
void Get_QueueLen(void);
int PutIn_Queue(void);
void PutOut_Queue(void);
void Traverse(void);
void Judge_Full(void);



#endif

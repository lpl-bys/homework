#include "AQueue.h"

char type;
char datatype[MAXQUEUE];
//int-0;longlong-1;float-2;double-3;char-4
/**
 *  @name        : void InitAQueue(AQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void InitAQueue(AQueue *Q){//
	Q->front=0;
	Q->rear=-1;
	Q->length=0;
	memset(Q->data,0,sizeof(Q->data));
	memset(datatype,0,sizeof(datatype));
	type=0;
}

/**
 *  @name        : void DestoryAQueue(AQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryAQueue(AQueue *Q){//
	while(DeAQueue(Q));
	free(Q);
	memset(datatype,0,sizeof(datatype));
	type=0;
}

/**
 *  @name        : Status IsFullAQueue(const AQueue *Q)
 *    @description : �������Ƿ�����
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsFullAQueue(const AQueue *Q){//
	if(Q->length>=MAXQUEUE) return TRUE;
	else return FALSE; 	
}

/**
 *  @name        : Status IsEmptyAQueue(const AQueue *Q)
 *    @description : �������Ƿ�Ϊ��
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsEmptyAQueue(const AQueue *Q){//
	if(!Q->length) return TRUE;
	else return FALSE;
}

/**
 *  @name        : Status GetHeadAQueue(AQueue *Q, void *e)
 *    @description : �鿴��ͷԪ��
 *    @param         Q ����ָ��Q�����Ԫ��e
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ��
 */
Status GetHeadAQueue(AQueue *Q, void *e){//
	if(IsEmptyAQueue(Q)) return FALSE;
	void *a;a=Q->data[Q->front];
	type=datatype[Q->front];
	switch(type){
		case 0: *(int *)e=(*(int *)a);
			break;
		case 1: *(long long *)e=(*(long long *)a);
			break;
		case 2: *(float *)e=(*(float *)a);
			break;
		case 3: *(double *)e=(*(double *)a);
			break;
		case 4: *(char *)e=(*(char *)a);
			break;
	//	default: 
				
	}
	return TRUE;
}

/**
 *  @name        : int LengthAQueue(AQueue *Q)
 *    @description : ȷ�����г���
 *    @param         Q ����ָ��Q
 *    @return         : ���г���count
 *  @notice      : None
 */
int LengthAQueue(AQueue *Q){//
	return Q->length;
}

/**
 *  @name        : Status EnAQueue(AQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ����˻�Ϊ��
 */
Status EnAQueue(AQueue *Q, void *data){//
	if(IsFullAQueue(Q)) return FALSE;
	if(Q->rear>=MAXQUEUE-1) Q->rear=0;
	else Q->rear++;
	Q->length++;
	switch(type){
		case 0: Q->data[Q->rear]=(int *)malloc(sizeof(int));
				*(int *)(Q->data[Q->rear])=(*(int *)data);
			break;
		case 1: Q->data[Q->rear]=(long long *)malloc(sizeof(long long));
				*(long long *)(Q->data[Q->rear])=(*(long long *)data);
			break;
		case 2: Q->data[Q->rear]=(float *)malloc(sizeof(float));
				*(float *)(Q->data[Q->rear])=(*(float *)data);
			break;
		case 3: Q->data[Q->rear]=(double *)malloc(sizeof(double));
				*(double *)(Q->data[Q->rear])=(*(double *)data);
			break;
		default: Q->data[Q->rear]=(char *)malloc(sizeof(char));
				 *(char *)(Q->data[Q->rear])=(*(char *)data);
		 
	}
	datatype[Q->rear]=type;
	return TRUE;	
}

/**
 *  @name        : Status DeAQueue(AQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeAQueue(AQueue *Q){//
	if(IsEmptyAQueue(Q)) return FALSE;
	free(Q->data[Q->front]);Q->data[Q->front]=NULL;
	if(Q->front>=MAXQUEUE-1) Q->front=0;
	else Q->front++;
	Q->length--;
	return TRUE;
}

/**
 *  @name        : void ClearAQueue(Queue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearAQueue(AQueue *Q){//
	while(DeAQueue(Q));
	Q->front=0;
	Q->rear=-1;
	memset(datatype,0,sizeof(datatype));
	type=0;
}

/**
 *  @name        : Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q))
 *    @description : ������������
 *    @param         Q ����ָ��Q����������ָ��foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q)){//
	if(IsEmptyAQueue(Q)) return FALSE; 
	bool flag=0;
	int zz=Q->front;
	for(int i=0;i<Q->length;i++){
		type=datatype[zz];
		if(flag) printf("   <-   ");
		else flag=1;
		(*foo)(Q->data[zz]);
		if(zz>=MAXQUEUE-1) zz=0;
		else zz++;
	}
	printf("\n");
	return TRUE;
}

/**
 *  @name        : void APrint(void *q)
 *    @description : ��������
 *    @param         q ָ��q
 *  @notice      : None
 */
void APrint(void *q){//
	switch(type){
		case 0: printf("%d",*(int *)q);
			break;
		case 1: printf("%lld",*(long long *)q);
			break;
		case 2: printf("%.3f",*(float *)q);
			break;
		case 3: printf("%lf",*(double *)q);
			break;
		case 4: printf("%c",*(char *)q);
			break;
	//	default: 
				
	}
}

#include "operation.h"

extern AQueue *que;
extern bool flag;
extern char type;
extern char datatype[MAXQUEUE];
extern int nextask;
char temp[233];

void mainlist(void){//0
	memset(temp,0,sizeof(temp));
	system("cls");
	printf("****************************************** Welcome to use que Maker *************************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Initialize the queue                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Judge empty                         |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Get the front element               |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Empty the queue                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. Destroy the queue                   |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Get the length of queue             |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     7. Put in new elements                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     8. Put out the elements                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     9. Traverse the queue                  |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     a. Judge full                          |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     b. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation...");
	scanf("%s",temp);getchar();
	switch(temp[0]){
		case '1': nextask=1;
		    break;
		case '2': nextask=2;
		    break;
		case '3': nextask=3;
		    break;
		case '4': nextask=4;
		    break;
		case '5': nextask=5;
		    break;
		case '6': nextask=6;
		    break;
		case '7': nextask=7;
		    break;
		case '8': nextask=8;
		    break;
		case '9': nextask=9;
			break;
		case 'a': nextask=10;
			break;
		case 'b': exit(0);
			break;
		default: 
				enter_wrong();
				enter_back();
				nextask=0;
	}
}


void Initialize_Queue(void){//1
	system("cls");
	if(flag) printf("The queue had been initialized!\n");
	else{
		que=(AQueue *)malloc(sizeof(AQueue));
		InitAQueue(que);
		flag=1;
		printf("Initialize successful!\n");
	}
	enter_back();
	nextask=0;
}

void Judge_Empty(void){//2
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else
		if(IsEmptyAQueue(que)) printf("The queue is empty!\n");
		else printf("The queue isn't empty!\n");
	enter_back();
	nextask=0;
}

void Get_TopElem(void){//3
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else {
		type=datatype[que->front];
		void *e;
		switch(type){
			case 0: e=(int *)malloc(sizeof(int));
				break;
			case 1: e=(long long *)malloc(sizeof(long long));
				break;
			case 2: e=(float *)malloc(sizeof(float));
				break;
			case 3: e=(double *)malloc(sizeof(double));
				break;
			default: e=(char *)malloc(sizeof(char));
		}
		if(GetHeadAQueue(que,e)){
			printf("Get successful!The front element is:");
			APrint(e);
			free(e);
			printf("\n");
		}
		else printf("The queue is empty!You can't get the element.\n");
	}
	enter_back();
	nextask=0;
}

void Empty_Queue(void){//4
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else{
		ClearAQueue(que);
		printf("Empty successful!\n");	
	}
	enter_back();
	nextask=0;
}

void Destroy_Queue(void){//5
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else{
		DestoryAQueue(que);
		que=NULL;
		flag=0;
		printf("Destroy successful!\n");
	}
	enter_back();
	nextask=0;
}

void Get_QueueLen(void){//6
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else printf("Get successful!The queue's length is: %d\n",LengthAQueue(que));
	enter_back();
	nextask=0;
}

int PutIn_Queue(void){//7
	system("cls");
	if(!flag){
		printf("The queue has not been initialized!\n");
		enter_back();nextask=0;
	}
	else{
		int t1;
		long long t2;
		float t3;
		double t4;
		char t5;
		void *t;
		memset(temp,0,sizeof(temp));
		printf("[1-int/2-longlong/3-float(С�������λ)/4-double(С�������λ)/5-char]\nPlease enter the number to choice the data's type:");
		scanf("%s",temp);getchar();
		printf("Please enter the data:");
		switch(temp[0]){
			case '1': type=0;
					  scanf("%d",&t1);getchar();
					  t=&t1;
				break;
			case '2': type=1;
					  scanf("%lld",&t2);getchar();
					  t=&t2;
				break;
			case '3': type=2;
					  scanf("%f",&t3);getchar();
					  t=&t3;
				break;
			case '4': type=3;
					  scanf("%lf",&t4);getchar();
					  t=&t4;
				break;
			case '5': type=4;
					  scanf("%c",&t5);getchar();
					  t=&t5;
				break;
			default:
				enter_wrong();
				printf("Please enter any key to try again!\n");
				getchar();
				nextask=7;
				return 0;
		}
		if(EnAQueue(que,t)){
			printf("Put in successful!\nContinue to put in(Y/N)?");
			memset(temp,0,sizeof(temp));
			scanf("%s",temp);getchar();
			if(temp[0]=='y'||temp[0]=='Y') nextask=7;
			else if(temp[0]=='n'||temp[0]=='N') nextask=0;
			else{
				enter_wrong();
				enter_back();
				nextask=0;
			}
		}
		else{
			printf("The queue is full!You can't add the element.\n");
			enter_back();
			nextask=0;
		}
	} 
}

void PutOut_Queue(void){//8
	system("cls");
	if(!flag){
		printf("The queue has not been initialized!\n");
		enter_back();nextask=0;
	}
	else{
		memset(temp,0,sizeof(temp));
		if(DeAQueue(que)){
			printf("Put out successful!\nContinue to put out?(Y/N):");
			scanf("%s",temp);getchar();
			if(temp[0]=='y'||temp[0]=='Y') nextask=8;
			else if(temp[0]=='n'||temp[0]=='N') nextask=0;
			else{
				enter_wrong();
				enter_back();
				nextask=0;
			}
		}
		else{
			printf("The queue is empty!You can't put out the element.\n");
			enter_back();
			nextask=0;
		}
	}
}

void Traverse(void){//9
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else
		if(TraverseAQueue(que,APrint)) printf("Show successful!\n");
		else printf("The queue is empty!\n");
	enter_back();nextask=0;
}

void Judge_Full(void){//10
	system("cls");
	if(!flag) printf("The queue has not been initialized!\n");
	else
		if(IsFullAQueue(que)) printf("The queue is full!\n");
		else printf("The queue isn't full!\n");
	enter_back();
	nextask=0;
}



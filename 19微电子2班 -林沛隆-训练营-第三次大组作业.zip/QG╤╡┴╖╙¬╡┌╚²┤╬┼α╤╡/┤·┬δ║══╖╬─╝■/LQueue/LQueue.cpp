#include "LQueue.h"

				
char type;

/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void InitLQueue(LQueue *Q){
	Q->front=NULL;
	Q->rear=NULL;
	Q->length=0; 
	type=0;
}

/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q){
	ClearLQueue(Q);
	free(Q);
}

/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *    @description : �������Ƿ�Ϊ��
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsEmptyLQueue(const LQueue *Q){
	if(!Q->length) return TRUE;
	else return FALSE;
}

/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *    @description : �鿴��ͷԪ��
 *    @param         Q e ����ָ��Q,��������ָ��e
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ��
 */
Status GetHeadLQueue(LQueue *Q, void *e){
	if(IsEmptyLQueue(Q)) return FALSE;
	type=(Q->front)->datatype;
	switch(type){
		case 0: *(int *)e=(*(int *)((Q->front)->data));
			break;
		case 1: *(long long *)e=(*(long long *)((Q->front)->data));
			break;	
		case 2: *(float *)e=(*(float *)((Q->front)->data));
			break;
		case 3: *(double *)e=(*(double *)((Q->front)->data));
			break;
		case 4: *(char *)e=(*(char *)((Q->front)->data));
			break;
	}
	return TRUE;
}

/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *    @description : ȷ�����г���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q){
	return Q->length;
}

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ�Ϊ��
 */
Status EnLQueue(LQueue *Q, void *data){
	Node *t;t=(Node *)malloc(sizeof(Node));
	if(IsEmptyLQueue(Q)){
		Q->front=t;
		Q->rear=t;
	}
	else{
		Q->rear->next=t;
		Q->rear=t;
	}
	t->next=NULL;
	t->datatype=type;
	Q->length++;
	switch(type){
		case 0: t->data=(int *)malloc(sizeof(int));
				*(int *)(t->data)=(*(int *)data);
			break;
		case 1: t->data=(long long *)malloc(sizeof(long long));
				*(long long *)(t->data)=(*(long long *)data);
			break;	
		case 2: t->data=(float *)malloc(sizeof(float));//*(float *)(t->data)=0; 
				*(float *)(t->data)=(*(float *)data);
			break;
		case 3: t->data=(double *)malloc(sizeof(double));//*(double *)(t->data)=0; 
				*(double *)(t->data)=(*(double *)data);
			break;
		case 4: t->data=(char *)malloc(sizeof(char));
				*(char *)(t->data)=(*(char *)data);
			break;
	}
	return TRUE;
}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q){
	if(IsEmptyLQueue(Q)) return FALSE;
	Node *t;t=Q->front->next;
	free(Q->front);
	Q->front=t;
	Q->length--;
	if(!Q->length) Q->rear=NULL;
	return TRUE;
}

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q){
	while(DeLQueue(Q));
	type=0;
}

/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *    @description : ������������
 *    @param         Q ����ָ��Q����������ָ��foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q)){
	if(IsEmptyLQueue(Q)) return FALSE;
	bool flag=0;
	Node *t;t=Q->front;
	while(t){
		if(flag) printf("   <-   ");
		else flag=1;
		type=t->datatype;
		(*foo)(t->data);
		t=t->next;
	}
	printf("\n");
	return TRUE;
}

/**
 *  @name        : void LPrint(void *q)
 *    @description : ��������
 *    @param         q ָ��q
 
 *  @notice      : None
 */
void LPrint(void *q){
	switch(type){
		case 0: printf("%d",*(int *)q);
			break;
		case 1: printf("%lld",*(long long *)q);
			break;
		case 2: printf("%.3f",*(float *)q);
			break;
		case 3: printf("%lf",*(double *)q);
			break;
		case 4: printf("%c",*(char *)q);
			break;
	}
}

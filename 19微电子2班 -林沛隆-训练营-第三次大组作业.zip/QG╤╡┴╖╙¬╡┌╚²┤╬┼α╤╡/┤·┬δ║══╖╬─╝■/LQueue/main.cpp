#include "operation.h"

bool flag;
LQueue *que;
int nextask;

void findtask(void);

int main(){
	system("color 1F");
	nextask=0;
	flag=0;
	que=NULL;
	while(1) findtask();
	return 0;
}

void findtask(void){
	switch(nextask){
		case 0: mainlist();
			break;
		case 1: Initialize_Queue();
			break;
		case 2: Judge_Empty();
			break;
		case 3: Get_TopElem();
			break;
		case 4: Empty_Queue();
			break;
		case 5: Destroy_Queue();
			break;
		case 6: Get_QueueLen();
			break;
		case 7: PutIn_Queue();
			break;
		case 8: PutOut_Queue();
			break;
		case 9: Traverse();
			break;
	}
}


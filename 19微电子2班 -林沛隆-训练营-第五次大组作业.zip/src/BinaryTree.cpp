#include "../inc/BinaryTree.h"

extern bool ifr;
extern int ten;

Status InitBiTree(BiTree T){ //����ն�����T
	T->data='#';
	//T->lchild=(BiTree)malloc(sizeof(BiTNode));
//	T->rchild=(BiTree)malloc(sizeof(BiTNode));
//	T->rchild->data='#';T->lchild->data='#';
	T->lchild=NULL;T->rchild=NULL;
	return SUCCESS;
} 

Status DestroyBiTree(BiTree T){ //�ݻٶ�����T
	if(!T) return ERROR;
	DestroyBiTree(T->lchild);
	DestroyBiTree(T->rchild);
	free(T);
	return SUCCESS;
}

Status CreateBiTree(BiTree T, char* definition){ //��definition���������T
	if(!definition[ten]) return ERROR;	
	if(definition[ten]!='#'){
		T->data=definition[ten++];
		T->tag=0;
		T->lchild=(BiTree)malloc(sizeof(BiTNode));
		T->rchild=(BiTree)malloc(sizeof(BiTNode));
		T->lchild->data='#';T->rchild->data='#';
		T->lchild->lchild=NULL;T->lchild->rchild=NULL;T->lchild->tag=0;
		T->rchild->lchild=NULL;T->rchild->rchild=NULL;T->rchild->tag=0;
		CreateBiTree(T->lchild,definition);
		CreateBiTree(T->rchild,definition);
	}
	else ten++;
	return SUCCESS;
}

Status PreOrderTraverse(BiTNode T, Status (*visit)(TElemType e)){ //�������;
	if(!(*visit)(T.data)) return ERROR;
	if(T.lchild) PreOrderTraverse(*(T.lchild),*visit);
	if(T.rchild) PreOrderTraverse(*(T.rchild),*visit);
	return SUCCESS;
}

Status InOrderTraverse(BiTNode T, Status (*visit)(TElemType e)){ //�������
	if(T.lchild) InOrderTraverse(*(T.lchild),*visit);
	if(!(*visit)(T.data)) return ERROR;
	if(T.rchild) InOrderTraverse(*(T.rchild),*visit);
	return SUCCESS;
}

Status PostOrderTraverse(BiTNode T, Status (*visit)(TElemType e)){ //�������
	if(T.lchild) PostOrderTraverse(*(T.lchild),*visit);
	if(T.rchild) PostOrderTraverse(*(T.rchild),*visit);
	if(!(*visit)(T.data)) return ERROR;
	return SUCCESS;
}

Status LevelOrderTraverse(BiTNode T, Status (*visit)(TElemType e)){	//�������
	BiTree que[2333];
	int head,tail;
	memset(que,0,sizeof(que));
	head=1;tail=1;
	que[head]=&T;
	while(head<=tail){
		(*visit)(que[head]->data);
		if(que[head]->lchild) que[++tail]=que[head]->lchild;
		if(que[head]->rchild) que[++tail]=que[head]->rchild;
		head++;
	}
	return SUCCESS;
}

int Value(BiTNode T){ //������Ķ�������ֵ
	if('0'<=T.data&&T.data<='9') return T.data-'0';
	int te=0;
	if(T.data=='+') te=Value(*(T.lchild))+Value(*(T.rchild));	
	else if(T.data=='*') te=Value(*(T.lchild))*Value(*(T.rchild));
	else if(T.data=='-') te=Value(*(T.lchild))-Value(*(T.rchild));
	else{
		if(!Value(*(T.rchild))){
			printf("������󣬳�������Ϊ��\n");
			ifr=0;
			return -1;
		}
		te=Value(*(T.lchild))/Value(*(T.rchild));
	}
	return te;
}

Status Print(TElemType e){
	if(e!='#'){
		printf("%c ",e);	
		return ERROR;
	}
	return SUCCESS;
}

Status PreOrderTraverseN(BiTNode T, Status (*visit)(TElemType e)){//�������(�ǵݹ�)8
	BiTree stack[2333],temp;
	memset(stack,0,sizeof(stack));
	int top=0;
	
	temp=&T;
	do{
		while(temp->data!='#'){
			(*visit)(temp->data);
			stack[++top]=temp;
			temp=temp->lchild;
		}
		if(top){
			temp=stack[top]->rchild;	
			top--;
		}
		else temp=NULL;
	}while(temp);

	return SUCCESS;
}

Status InOrderTraverseN(BiTNode T, Status (*visit)(TElemType e)){	//�������(�ǵݹ�)8
	BiTree stack[2333],temp;
	memset(stack,0,sizeof(stack));
	int top=0;
	
	temp=&T;
	do{
		while(temp->data!='#'){
			stack[++top]=temp;
			temp=temp->lchild;
		}
		if(top){
			temp=stack[top];
			(*visit)(temp->data);
			temp=stack[top]->rchild;
			top--;
		}
		else temp=NULL;
	}while(temp);
	
	return SUCCESS;
}

Status PostOrderTraverseN(BiTNode T, Status (*visit)(TElemType e)){	//�������(�ǵݹ�)
	BiTree stack[2333],temp;
	memset(stack,0,sizeof(stack));
	int top=0;
	
	temp=&T;
	do{
		while(temp->data!='#'){
			stack[++top]=temp;
			temp=temp->lchild;
		}
		if(top){
			temp=stack[top];
			while(top&&temp->tag){
				(*visit)(temp->data);
				temp=stack[--top];
			}
			if(!top) break;
			temp->tag=1;
			temp=stack[top]->rchild;
		}
		else temp=NULL;
	}while(temp);
	
	return SUCCESS;
}

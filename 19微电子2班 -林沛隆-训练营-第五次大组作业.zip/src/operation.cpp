#include "../inc/operation.h"

BiTree tree;
bool flag,ifr;
extern int nextask;
int ten; 

void Init(void){//1
	system("cls");
	if(!flag){
		tree=(BiTree)malloc(sizeof(BiTNode));
		InitBiTree(tree);
		flag=1;
		printf("��ʼ���ɹ�\n");
	}
	else printf("���Ѵ���\n");	
	enter_back();
	nextask=0;
}

void Destroy(void){//2
	system("cls");
	if(!flag) printf("��δ��ʼ��\n");
	else{
		DestroyBiTree(tree);
		flag=0;
		printf("���ٳɹ�\n");
	}
	enter_back();
	nextask=0;
}

void Create(void){//3
	system("cls");
	if(!flag) printf("��δ��ʼ��\n");
	else if((tree->data)!='#') printf("���ѱ�ռ�ã���������ٺͳ�ʼ�������ԣ�\n");
	else{
		char temp[2333];
		memset(temp,0,sizeof(temp));
		ten=0;
	
		printf("���������������(��#�������������������ʾ������A(B(D(#,#),E(#,#)),C(#,#)))��ʾΪ ABD##E##C##):");
		scanf("%s",temp);getchar();
	
		CreateBiTree(tree,temp);
		
		printf("�����ɹ�\n");
	}
	enter_back();
	nextask=0;
}

void Traverse(void){//4
	system("cls");
	if(!flag) printf("��δ����\n");
	else{
		char temp[233];
		memset(temp,0,sizeof(temp));
		
		printf("��ѡ�������ʽ(1.����;2.����;3.����;4.����)��");
		scanf("%s",temp);getchar();
		
		if(temp[0]=='1'){
			PreOrderTraverse(*tree,Print);
			printf("\n");
		}
		else if(temp[0]=='2'){
			InOrderTraverse(*tree,Print);
			printf("\n");
		}
		else if(temp[0]=='3'){
			PostOrderTraverse(*tree,Print);
			printf("\n");
		}
		else if(temp[0]=='4'){
			LevelOrderTraverse(*tree,Print);
			printf("\n");
		}
		else{
			enter_wrong();
			nextask=0;
		}
		
	}
	enter_back();
	nextask=0;
}

void Calculation(void){//5
	system("cls");
	ifr=1;
	char temp[2333],c;
	memset(temp,0,sizeof(temp));
	ten=0;

	printf("������ǰ׺����ʽ(�磺+2*34)��");
	while(1){
		c=getchar();
		if(c=='\n') break;
		if('0'<=c&&c<='9'){
			temp[ten++]=c;
			temp[ten++]='#';
			temp[ten++]='#';
		}
		else if(c=='*'||c=='-'||c=='+'||c=='/') temp[ten++]=c;
		else{
			while(c!='\n') c=getchar();
			enter_wrong();
			enter_back();
			nextask=0;
			return;
		}
	}
	
	if(flag) DestroyBiTree(tree);
	tree=(BiTree)malloc(sizeof(BiTNode));
	InitBiTree(tree);
	flag=1;
	
	ten=0;
	
	CreateBiTree(tree,temp);

	if(ifr) printf("������Ϊ: %d\n",Value(*tree));
	
	enter_back();
	nextask=0;
}

void TraverseN(void){//6
	system("cls");
	if(!flag) printf("��δ����\n");
	else{
		char temp[233];
		memset(temp,0,sizeof(temp));
		
		printf("��ѡ��ǵݹ������ʽ(1.����;2.����;3.����)��");
		scanf("%s",temp);getchar();
		
		if(temp[0]=='1'){
			PreOrderTraverseN(*tree,Print);
			printf("\n");
		}
		else if(temp[0]=='2'){
			InOrderTraverseN(*tree,Print);
			printf("\n");
		}
		else if(temp[0]=='3'){
			PostOrderTraverseN(*tree,Print);
			printf("\n");
		}
		else{
			enter_wrong();
			nextask=0;
		}
		
	}
	enter_back();
	nextask=0;
}

void mainlist(void){//0
	char temp[233];
	memset(temp,0,sizeof(temp));
	system("cls");
	printf("****************************************** Welcome to use tree maker *************************************************\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     1. Initialize the tree                 |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     2. Destroy the tree                    |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     3. Create the tree                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     4. Travel the tree                     |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     5. Calculate the tree                  |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     6. Travel the tree(�ǵݹ��)           |\n");
	printf("                                |--------------------------------------------|\n");
	printf("                                |     a. Exit                                |\n");
	printf("                                |--------------------------------------------|\n");
	printf("***********************************************************************************************************************\n");
	printf("\t Please enter the number to choice the operation...");
	scanf("%s",temp);getchar();
	switch(temp[0]){
		case '1': nextask=1;
		    break;
		case '2': nextask=2;
		    break;
		case '3': nextask=3;
		    break;
		case '4': nextask=4;
		    break;
		case '5': nextask=5;
		    break;
		case '6': nextask=6;
		    break;
		case 'a': exit(0);
			break;
		default: 
				enter_wrong();
				enter_back();
				nextask=0;
	}
}


#include "../inc/operation.h"
#include "../inc/public.h"

int nextask;
extern bool flag;

void findtask(void);

int main(){
	system("color bc");
	nextask=0;
	flag=0;
	while(1) findtask();
	return 0;
}

void findtask(void){
	switch(nextask){
		case 0: mainlist();
			break;
		case 1: Init();
			break;
		case 2: Destroy();
			break;
		case 3: Create();
			break;
		case 4: Traverse();
			break;
		case 5: Calculation();
			break;
		case 6: TraverseN();
			break;
	}
}


#include "../inc/public.h"

void enter_wrong(void){
	printf("Entering error!Please cheak your input and try again!\n");
}

void run_wrong(void){
	system("cls");
	printf("Runtime error!Please contact the producers.\n");
	printf("Please enter any key to exit...");
	getchar();
	exit(0);
}

void enter_back(void){
	printf("Please press enter to back...");
	getchar();
}

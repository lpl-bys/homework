#ifndef _operation_H
#define _operation_H

#include "../inc/public.h"
#include "../inc/BinaryTree.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

void mainlist(void);//0
void Init(void);//1
void Destroy(void);//2
void Create(void);//3
void Traverse(void);//4
void Calculation(void);//5
void TraverseN(void);//6


#endif
